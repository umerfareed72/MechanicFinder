import React, {StyleSheet, Dimensions} from 'react-native';

module.exports = {
 

};
